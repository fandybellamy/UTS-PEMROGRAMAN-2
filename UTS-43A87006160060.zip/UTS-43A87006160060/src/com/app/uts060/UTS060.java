/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.uts060;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author FDK
 */
public class UTS060 {
    public static void main(String[] args) {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setServerName("localhost");
        dataSource.setDatabaseName("rumahsakit");
        dataSource.setUser("root");
        
        try {
            Connection connection = dataSource.getConnection();
            System.out.println("Koneksi Berhasil");
        } catch (SQLException ex) {
            System.out.println("Koneksi Gagal");
            System.out.println("Error: "+ex.getMessage());
            Logger.getLogger(UTS060.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}

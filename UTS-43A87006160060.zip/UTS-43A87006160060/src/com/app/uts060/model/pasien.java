/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.uts060.model;

/**
 *
 * @author FDK
 */
public class pasien {
    private String idpasien;
    private String nama;
    private String penyakit;
    private String dokter;
    private String umur;

    public pasien() {
    }

    public pasien(String idpasien, String nama, String penyakit, String dokter, String umur) {
        this.idpasien = idpasien;
        this.nama = nama;
        this.penyakit = penyakit;
        this.dokter = dokter;
        this.umur = umur;
    }

    public String getIdpasien() {
        return idpasien;
    }

    public void setIdpasien(String idpasien) {
        this.idpasien = idpasien;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getPenyakit() {
        return penyakit;
    }

    public void setPenyakit(String penyakit) {
        this.penyakit = penyakit;
    }

    public String getDokter() {
        return dokter;
    }

    public void setDokter(String dokter) {
        this.dokter = dokter;
    }

    public String getUmur() {
        return umur;
    }

    public void setUmur(String umur) {
        this.umur = umur;
    }
    
     
}

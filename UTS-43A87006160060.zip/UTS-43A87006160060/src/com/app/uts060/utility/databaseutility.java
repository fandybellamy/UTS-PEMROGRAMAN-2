/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.uts060.utility;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import com.sun.istack.internal.logging.Logger;
import java.rmi.ConnectException;
import java.sql.SQLException;

/**
 *
 * @author FDK
 */
public class databaseutility {
    private static ConnectException connection;

    static {
        MysqlDataSource ds = new MysqlDataSource();
        ds.setServerName("localhost");
        ds.setDatabaseName("pasien");
        ds.setUser("root");
        try {
        connection = ds.getConnection();
        } catch (SQLException ex) {
            System.out.println("Error; " + ex.getMessage());
        }
        
    }
    
    public static ConnectException getConnection() {
        return connection;
    }
    
    
}

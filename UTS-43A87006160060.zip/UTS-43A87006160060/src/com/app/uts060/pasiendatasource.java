/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.uts060;

import com.app.uts060.model.pasien;
import com.app.uts060.utility.databaseutility;
import java.rmi.ConnectException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FDK
 */
public class pasiendatasource {
    private Connection connection;
    private pasien pasien;
    
    public pasiendatasource(){
        connection = databaseutility.getConnection();
        
    }
    
    public List<pasien> getALL (){
        List<pasien> list = new ArrayList<>();
        String sql = "SELECT * FROM pasien";
        
        try {
            PreparedStatement statement = connection.prepareCall(sql);
            ResultSet rs = statement.executeQuery();
            pasien pasien;
           
            while (rs.next())
                pasien = new pasien();
                pasien.setIdpasien(rs.getString("idpasien")); 
                pasien.setNama(rs.getString("nama"));
                pasien.setPenyakit(rs.getString("penyakit"));
                pasien.setDokter(rs.getString("dokter"));
                pasien.setUmur(rs.getString("umur"));
                list.add(pasien);
                
                
        } catch (Exception e) {
        }
    }
}
